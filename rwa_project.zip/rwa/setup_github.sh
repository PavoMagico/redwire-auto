#!/bin/bash
# ============================================================
# Red Wire Auto — Script de configuración del repositorio
# Ejecutar desde la carpeta raíz del repo (donde está el README.md)
# ============================================================

echo ""
echo "🚗 Red Wire Auto — Configurando repositorio..."
echo ""

# Verificar que estamos en el repo correcto
if [ ! -f "README.md" ]; then
  echo "❌ Error: ejecuta este script desde la carpeta del repositorio (donde está el README.md)"
  exit 1
fi

# 1. Eliminar archivos sueltos del raíz que no deberían estar ahí
echo "🗑  Eliminando archivos sueltos incorrectos..."
git rm -f Test.jsx index.js schema.sql testController.js RWA_CONTEXT.md RedWireAuto_Entrega3.docx 2>/dev/null || true
git rm -rf .vscode 2>/dev/null || true

# 2. Copiar la nueva estructura desde la carpeta rwa/ al raíz
echo "📁 Copiando estructura de carpetas..."
cp -r rwa/db .
cp -r rwa/server .
cp -r rwa/client .

# 3. Crear .gitignore raíz
cat > .gitignore << 'EOF'
# Dependencias
node_modules/

# Variables de entorno (nunca subir al repo)
.env
server/.env
client/.env

# Build de producción
client/dist/

# Editores
.vscode/
.idea/
*.swp
.DS_Store
EOF

# 4. Eliminar la carpeta rwa/ temporal
rm -rf rwa/

echo ""
echo "✅ Estructura creada correctamente."
echo ""

# 5. Commit y push
echo "📤 Subiendo a GitHub..."
git add .
git commit -m "refactor: estructura completa del proyecto (server + client + db)"
git push

echo ""
echo "🎉 ¡Listo! Repositorio actualizado en GitHub."
echo ""
echo "📋 Próximos pasos para ejecutar el proyecto:"
echo "   1. cd server && cp .env.example .env  (edita con tus datos MySQL)"
echo "   2. mysql -u root -p < db/schema.sql"
echo "   3. cd server && npm install && npm run dev"
echo "   4. cd client && npm install && npm run dev"
echo ""
